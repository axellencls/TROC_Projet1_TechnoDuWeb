import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { ListeMembresComponent } from './liste-membres/liste-membres.component';
import { MembresService } from './membres.service';

@NgModule({
declarations: [ListeMembresComponent],
  imports: [
    BrowserModule, HttpClientModule
  ],
  exports: [ListeMembresComponent],
  providers: [MembresService]
})
export class MembresModule { }
